// Set up the scene, camera, and renderer
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js';




class windowConfig{
  constructor(params) {
    this.scene = new THREE.Scene();
    
    
// window.addEventListener('DOMContentLoaded', () => {
//   this.scene = new THREE.Scene();
  
// });
    // this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    this.renderer = new THREE.WebGLRenderer({antialias:true});
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.renderer.setSize(window.innerWidth * 0.816, window.innerHeight); // Half the window width
    document.body.appendChild(this.renderer.domElement)
    this.windowModel= null
    const orbit = new OrbitControls(this.camera, this.renderer.domElement);
    orbit.maxPolarAngle = 1.5;
  console.log("aa",orbit.maxPolarAngle )  
    orbit.update()
    this.Init();

    
  }
  

  Init(){
window.addEventListener('resize', this.onWindowResize, false);

    this.camera.position.set(0, 0, 5);
    this.scene.background = new THREE.Color( 'grey' );

    this.loadGLBModel();
    this.setupLighting();
    this.animate();




  }
  loadGLBModel() {
    this.loadingManager = new THREE.LoadingManager()
    const manager = new THREE.LoadingManager();


    const glbLoader = new GLTFLoader(manager);
    manager.onLoad = () => {
      this.meshes = []
      for(let i =0 ;i< this.windowModel.children.length ;i++){
        this.meshes[i] = this.windowModel.children[i]
      }
      console.log( this.gltf ,"gltf.scene bb", this.windowModel, this.meshes, this.windowModel.children.length)
      this.temp = this.meshes[0]
      if (this.temp.material) {
        this.temp.material = this.temp.material.clone(); // NOTE Create unique instance of the original material, only applied to this mesh
        this.temp.material.color.set("black");
      }

    };
  
    glbLoader.load('assets/chair.gltf', (gltf) => {
      // Assuming the GLB file contains a scene
      this.gltf = gltf
      this.windowModel = gltf.scene;
      this.scene.add(gltf.scene); // Add the scene from the GLTF file, not the GLTF object itself
      
      // Optional: Set the scale, position, or rotation of the model if necessary
      this.windowModel.scale.set(1, 1, 1);
      this.windowModel.position.set(0, -2, 0);
      // this.windowModel.rotation.set(0, 0, 0);
  
    }, console.log( this.gltf,"gltf.scene aa", this.windowModel), (error) => {
      console.error(error);
    });
  }
  setupLighting() {
    const ambientLight = new THREE.AmbientLight(0xffffff, 10);
    ambientLight.position.set(5, 20, 10);
    this.scene.add(ambientLight);}

    animate() {
      requestAnimationFrame(this.animate.bind(this)); // Make sure to bind this or use an arrow function
      // // Any rotation or animation logic here
      this.renderer.render(this.scene, this.camera);
    }
    
    // Somewhere in your Init() method, start the animation loop


    onWindowResize() {
      // this.camera.aspect = (window.innerWidth * 0.816) / window.innerHeight;
      // this.camera.updateProjectionMatrix();
      // this.renderer.setSize(window.innerWidth * 0.816, window.innerHeight);
    }
    
}





// Handle window resizing

window.addEventListener("DOMContentLoaded",()=>{
  let loaderScreen = document.getElementById("loader");
  
  const threeScene = new windowConfig();
  loaderScreen.style.display = "none";

})

